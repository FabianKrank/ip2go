%% Problem laden
problemdata = [];
load('structures\matrix_structures_modus3.mat');
problemdata = matrix_structure;
problemdata.xinit= zeros(6,1);

% Alternativ:
%load('structures\problemdata_4.mat');

%% Generation-Data ausf�llen
generation_data = gen_lqdocpip_default_generation_data();

generation_data.name = 'mpc123';

generation_data.timer = {'windows' 'dspace'};

generation_data.starting_point_methode = 5;
generation_data.precision = 'float';

generation_data.debug = 1;

% Dimensionen
% Diskretisierungsschritte
generation_data.dim.K           = size(problemdata.Hxx,1)-1;
% Zust�nde
generation_data.dim.n_x         = size(problemdata.Hxx{1},1);
% Eing�nge
generation_data.dim.n_u         = size(problemdata.Huu{1},1);
% UGNBs und Schlupf
generation_data.dim.n_c         = zeros(generation_data.dim.K+1,1);
generation_data.dim.n_s         = zeros(generation_data.dim.K+1,1);
for ii = 1:generation_data.dim.K+1
    generation_data.dim.n_c(ii) = size(problemdata.gx{ii},1);
    generation_data.dim.n_s(ii) = size(problemdata.Hss{ii},1);
end

clear ii

generation_data.loopunrolling = 1;

generation_data.path_target = 'C:\Users\fabia\OneDrive\Documents\Codegenerator\code';

%% Strukturausnutzung
if 1
    generation_data.use_structures = 1;
    generation_data.matrix_structures = problemdata;
    
else
    generation_data.use_structures = 0;
end

%% Performancetests
if 1
    cd('performance_test');
    
    generation_data.performance_test = 1;
    procedure_tests = performance_tests_procedures_load();
    math_tests      = performance_tests_math_load();
    structure_tests = performance_tests_structure_load();
    % Add Tests to gendata
    %generation_data.performance_tests = cell(0);
    %generation_data.performance_tests = {generation_data.performance_tests{1:end} math_tests{3}};
    %generation_data.performance_tests = {generation_data.performance_tests{1:end} structure_tests{4}};
    %generation_data.performance_tests = {generation_data.performance_tests{1:end} procedure_tests{2:6} procedure_tests{end-1:end}};
    
    % Tests in Studienarbeit / dSpace
    if 1
        generation_data.performance_tests = cell(0);
        generation_data.performance_tests(end+1) = procedure_tests(22); % 1 iteration
        generation_data.performance_tests(end+1) = procedure_tests(3);  % Factor
        generation_data.performance_tests(end+1) = procedure_tests(4);  % Solve
        generation_data.performance_tests(end+1) = procedure_tests(1);  % affine
        generation_data.performance_tests(end+1) = procedure_tests(2);  % reduced
        generation_data.performance_tests(end+1) = procedure_tests(5);  % dereduce
        generation_data.performance_tests(end+1) = procedure_tests(10); % norm_r
        generation_data.performance_tests(end+1) = structure_tests(4);  % structure_mult_m_fx0
        generation_data.performance_tests(end+1) = procedure_tests(23); % 1 iteration_iterref
        generation_data.performance_tests(end+1) = procedure_tests(6);  % starting Point
    else % Sonst alle Tests
        generation_data.performance_tests = cell(0);
        generation_data.performance_tests = {generation_data.performance_tests{1:end} math_tests{1:end}};
        generation_data.performance_tests = {generation_data.performance_tests{1:end} structure_tests{1:end}};
        generation_data.performance_tests = {generation_data.performance_tests{1:end} procedure_tests{1:end}};
    end
    
    for ii = 1:length(generation_data.performance_tests)
        generation_data.performance_tests{ii}.iterations = 1;
    end
    
    clear ii procedure_tests math_tests structure_tests
    cd('..');
else
    generation_data.performance_test = 0;
end

%% Solver generieren
gen_lqdocpip(generation_data);

%% Matlab-Interface generieren
gen_wrap();

%% Mex
cd([pwd '\code']);
mex mpc123_wrap.c mpc123_glqdocpip.c

%% Ausf�hren
mpc123_wrap(problemdata);
cd('..')
