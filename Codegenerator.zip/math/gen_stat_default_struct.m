function [output] = gen_stat_default_struct()
%GEN_STAT_DEFAULT_STRUCT Summary of this function goes here
%   Detailed explanation goes here
output.funid = '';
output.add = 0;
output.mult = 0;
output.multadd = 0;
output.div = 0;
output.copy = 0;
output.init = 0;
output.if = 0;

end

