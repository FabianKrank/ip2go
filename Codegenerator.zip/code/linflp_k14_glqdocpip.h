/* ########### */
/* # INCLUDE # */
/* ########### */


float *linflp_k14_get_x0();
float *linflp_k14_get_x(int k);
float *linflp_k14_get_u(int k);
float *linflp_k14_get_s(int k);
float *linflp_k14_get_p(int k);
float *linflp_k14_get_y(int k);
float *linflp_k14_get_nu(int k);
float *linflp_k14_get_Hxx(int k);
float *linflp_k14_get_Hxu(int k);
float *linflp_k14_get_Huu(int k);
float *linflp_k14_get_Hss(int k);
float *linflp_k14_get_f0x(int k);
float *linflp_k14_get_f0u(int k);
float *linflp_k14_get_f0s(int k);
float *linflp_k14_get_fx(int k);
float *linflp_k14_get_fu(int k);
float *linflp_k14_get_f(int k);
float *linflp_k14_get_gx(int k);
float *linflp_k14_get_gu(int k);
float *linflp_k14_get_g(int k);
float *linflp_k14_get_stat_time();
int *linflp_k14_get_stat_iter_ref();
int *linflp_k14_get_stat_num_factor();
int *linflp_k14_get_stat_num_solve();
int *linflp_k14_get_stat_num_iter_ref();
int *linflp_k14_get_iter();
int *linflp_k14_get_termcode();
int *linflp_k14_get_error_line();
int *linflp_k14_get_error_source();
float *linflp_k14_get_norm_d();
double *linflp_k14_get_time_max();
void linflp_k14_set_time_max(double tmax);

double linflp_k14_glqdocpip_timer_get();
void linflp_k14_glqdocpip_timer_start();
int linflp_k14_glqdocpip();
