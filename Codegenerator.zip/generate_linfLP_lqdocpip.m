% Skript zum Erstellen des generierten Codes zum Vergleich mit anderen
% Solvern

%% Problem laden (f�r Strukturausnutzung)
%load('C:\Users\neXus\OneDrive\Documents\Codegenerator\tragentov.mat')

%% Generation-Data ausf�llen
generation_data = gen_lqdocpip_default_generation_data();

generation_data.name = 'linflp_k14';

generation_data.timer = {'windows'};

generation_data.starting_point_methode = 0;
generation_data.precision = 'float';

generation_data.parameter.max_iter = 100;

generation_data.debug = 0;

% Dimensionen
% Diskretisierungsschritte
generation_data.dim.K           = 14;
% Zust�nde
generation_data.dim.n_x         = 3;
% Eing�nge
generation_data.dim.n_u         = 2;
% UGNBs und Schlupf
generation_data.dim.n_c         = 10*ones(generation_data.dim.K+1,1);
generation_data.dim.n_s         = zeros(generation_data.dim.K+1,1);


generation_data.loopunrolling = 1;
generation_data.use_structures = 0;
generation_data.matrix_structures = problemdata;

generation_data.performance_test = 0;


%% Solver generieren
gen_lqdocpip(generation_data);

%% Matlab-Interface generieren
gen_wrap();

%% Mex
eval(['mex ' generation_data.name '_wrap.c ' generation_data.name '_glqdocpip.c'])


